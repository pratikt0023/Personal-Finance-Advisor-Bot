import os
import json
import google.generativeai as genai
from flask import current_app


def _get_model():
    api_key = current_app.config.get("GEMINI_API_KEY") or os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return None
    genai.configure(api_key=api_key)
    model_name = current_app.config.get("GEMINI_MODEL", "gemini-2.0-flash")
    return genai.GenerativeModel(model_name)


def _clean_json(text):
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    return json.loads(text.strip())


def _fallback_budget(total_income, expenses_by_category):
    needs = round(total_income * 0.5, 2)
    wants = round(total_income * 0.3, 2)
    savings = round(total_income * 0.2, 2)
    return {
        "summary": "AI key not configured, so here is a standard 50/30/20 budget instead.",
        "recommended_allocations": {"Needs": needs, "Wants": wants, "Savings": savings},
        "tips": [
            "Add GEMINI_API_KEY to your .env file for personalized AI budgets.",
            "Review your largest expense categories for savings opportunities.",
            "Aim to save at least 20% of your income each month.",
        ],
    }


def generate_budget_plan(total_income, expenses_by_category, savings_goal=None):
    model = _get_model()
    if not model:
        return _fallback_budget(total_income, expenses_by_category)

    prompt = f"""You are a personal finance advisor. A user has a monthly income of {total_income}.
Their recent spending by category is: {json.dumps(expenses_by_category)}.
Savings goal: {savings_goal or "not specified"}.

Respond ONLY with valid JSON, no markdown formatting, no backticks, in exactly this shape:
{{
  "summary": "2-3 sentence overview of their financial situation",
  "recommended_allocations": {{"CategoryName": amount}},
  "tips": ["tip 1", "tip 2", "tip 3"]
}}"""
    try:
        response = model.generate_content(prompt)
        return _clean_json(response.text)
    except Exception as e:
        fallback = _fallback_budget(total_income, expenses_by_category)
        fallback["error"] = f"AI generation failed, showing a fallback plan instead ({e})."
        return fallback


def analyze_spending(expenses_by_category, budgets_by_category):
    over_budget = {
        cat: {"spent": spent, "limit": budgets_by_category.get(cat, 0)}
        for cat, spent in expenses_by_category.items()
        if budgets_by_category.get(cat) and spent > budgets_by_category[cat]
    }

    model = _get_model()
    if not model:
        return {
            "overspending": over_budget,
            "insights": ["Add GEMINI_API_KEY to your .env file for AI-generated insights."],
        }

    prompt = f"""A user's spending by category: {json.dumps(expenses_by_category)}.
Their monthly budget limits by category: {json.dumps(budgets_by_category)}.
Identify overspending and give exactly 3 short, practical cost-optimization tips.
Respond ONLY with valid JSON, no markdown: {{"overspending": {{}}, "insights": ["", "", ""]}}"""
    try:
        response = model.generate_content(prompt)
        return _clean_json(response.text)
    except Exception:
        return {
            "overspending": over_budget,
            "insights": ["Could not reach the AI service just now — showing raw overspending data."],
        }


def chat_with_advisor(user_message, financial_context):
    model = _get_model()
    if not model:
        return "AI chat isn't configured yet. Add a GEMINI_API_KEY to your .env file to enable this feature."

    prompt = f"""You are a friendly, practical personal finance advisor chatbot.
The user's current financial context: {json.dumps(financial_context)}.
The user says: "{user_message}"

Give a helpful, specific, concise response (under 120 words). Do not give formal investment,
tax, or legal advice beyond general best practices, and say so if asked for that."""
    try:
        response = model.generate_content(prompt)
        return response.text.strip()
    except Exception as e:
        return f"Sorry, I couldn't reach the AI service right now ({e})."
