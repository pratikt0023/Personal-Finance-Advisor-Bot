from datetime import datetime
from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user

from extensions import db
from models import Income, Expense, ExpenseCategory, Budget, SavingsGoal
from ai_advisor import generate_budget_plan

finance_bp = Blueprint("finance", __name__)

DEFAULT_CATEGORIES = ["Housing", "Food", "Transport", "Utilities", "Entertainment", "Other"]


def ensure_default_categories():
    existing = {c.name for c in ExpenseCategory.query.filter_by(user_id=current_user.id).all()}
    for name in DEFAULT_CATEGORIES:
        if name not in existing:
            db.session.add(ExpenseCategory(user_id=current_user.id, name=name))
    db.session.commit()


@finance_bp.route("/income", methods=["GET", "POST"])
@login_required
def income():
    if request.method == "POST":
        source = request.form.get("source", "").strip()
        try:
            amount = float(request.form.get("amount", 0) or 0)
        except ValueError:
            amount = 0
        if source and amount > 0:
            db.session.add(Income(user_id=current_user.id, source=source, amount=amount))
            db.session.commit()
            flash("Income recorded.", "success")
        else:
            flash("Enter a source and a positive amount.", "error")
        return redirect(url_for("finance.income"))

    incomes = Income.query.filter_by(user_id=current_user.id).order_by(Income.date_received.desc()).all()
    total = sum(i.amount for i in incomes)
    return render_template("income.html", incomes=incomes, total=total)


@finance_bp.route("/income/<int:income_id>/delete", methods=["POST"])
@login_required
def delete_income(income_id):
    inc = Income.query.filter_by(id=income_id, user_id=current_user.id).first_or_404()
    db.session.delete(inc)
    db.session.commit()
    return redirect(url_for("finance.income"))


@finance_bp.route("/expenses", methods=["GET", "POST"])
@login_required
def expenses():
    ensure_default_categories()
    categories = ExpenseCategory.query.filter_by(user_id=current_user.id).all()

    if request.method == "POST":
        try:
            category_id = int(request.form.get("category_id"))
            amount = float(request.form.get("amount", 0) or 0)
        except (TypeError, ValueError):
            category_id, amount = None, 0
        description = request.form.get("description", "").strip()

        if category_id and amount > 0:
            db.session.add(Expense(user_id=current_user.id, category_id=category_id,
                                    amount=amount, description=description))
            db.session.commit()
            flash("Expense recorded.", "success")
        else:
            flash("Choose a category and enter a positive amount.", "error")
        return redirect(url_for("finance.expenses"))

    expense_list = Expense.query.filter_by(user_id=current_user.id).order_by(Expense.date_spent.desc()).all()
    total = sum(e.amount for e in expense_list)
    return render_template("expenses.html", expenses=expense_list, categories=categories, total=total)


@finance_bp.route("/expenses/<int:expense_id>/delete", methods=["POST"])
@login_required
def delete_expense(expense_id):
    exp = Expense.query.filter_by(id=expense_id, user_id=current_user.id).first_or_404()
    db.session.delete(exp)
    db.session.commit()
    return redirect(url_for("finance.expenses"))


@finance_bp.route("/categories", methods=["POST"])
@login_required
def add_category():
    name = request.form.get("name", "").strip()
    try:
        limit = float(request.form.get("monthly_limit", 0) or 0)
    except ValueError:
        limit = 0
    if name:
        db.session.add(ExpenseCategory(user_id=current_user.id, name=name, monthly_limit=limit))
        db.session.commit()
        flash("Category added.", "success")
    return redirect(url_for("finance.expenses"))


@finance_bp.route("/budget", methods=["GET", "POST"])
@login_required
def budget():
    ensure_default_categories()
    month = datetime.utcnow().strftime("%Y-%m")

    incomes = Income.query.filter_by(user_id=current_user.id).all()
    total_income = sum(i.amount for i in incomes)

    categories = ExpenseCategory.query.filter_by(user_id=current_user.id).all()
    expenses_by_category = {c.name: sum(e.amount for e in c.expenses) for c in categories if c.expenses}

    plan = None
    if request.method == "POST":
        goal = request.form.get("savings_goal", "").strip()
        plan = generate_budget_plan(total_income, expenses_by_category, goal or None)

        existing = Budget.query.filter_by(user_id=current_user.id, month=month).first()
        if existing:
            existing.total_income = total_income
            existing.ai_plan = str(plan)
        else:
            db.session.add(Budget(user_id=current_user.id, month=month,
                                   total_income=total_income, ai_plan=str(plan)))
        db.session.commit()

    return render_template("budget.html", plan=plan, total_income=total_income,
                            expenses_by_category=expenses_by_category)


@finance_bp.route("/savings", methods=["GET", "POST"])
@login_required
def savings():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        try:
            target = float(request.form.get("target_amount", 0) or 0)
        except ValueError:
            target = 0
        if name and target > 0:
            db.session.add(SavingsGoal(user_id=current_user.id, name=name, target_amount=target))
            db.session.commit()
            flash("Savings goal added.", "success")
        return redirect(url_for("finance.savings"))

    goals = SavingsGoal.query.filter_by(user_id=current_user.id).all()
    return render_template("savings.html", goals=goals)


@finance_bp.route("/savings/<int:goal_id>/add", methods=["POST"])
@login_required
def add_to_savings(goal_id):
    goal = SavingsGoal.query.filter_by(id=goal_id, user_id=current_user.id).first_or_404()
    try:
        amount = float(request.form.get("amount", 0) or 0)
    except ValueError:
        amount = 0
    goal.current_amount += amount
    db.session.commit()
    return redirect(url_for("finance.savings"))
