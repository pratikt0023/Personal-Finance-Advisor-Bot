from flask import Blueprint, render_template, request
from flask_login import login_required, current_user

from models import Income, ExpenseCategory, SavingsGoal
from ai_advisor import analyze_spending, chat_with_advisor

dashboard_bp = Blueprint("dashboard", __name__)


def _financial_snapshot():
    incomes = Income.query.filter_by(user_id=current_user.id).all()
    total_income = sum(i.amount for i in incomes)

    categories = ExpenseCategory.query.filter_by(user_id=current_user.id).all()
    expenses_by_category = {c.name: sum(e.amount for e in c.expenses) for c in categories if c.expenses}
    budgets_by_category = {c.name: c.monthly_limit for c in categories if c.monthly_limit}

    return total_income, expenses_by_category, budgets_by_category


@dashboard_bp.route("/")
@login_required
def index():
    total_income, expenses_by_category, budgets_by_category = _financial_snapshot()
    total_expenses = sum(expenses_by_category.values())

    savings_goals = SavingsGoal.query.filter_by(user_id=current_user.id).all()
    total_saved = sum(g.current_amount for g in savings_goals)

    insights = analyze_spending(expenses_by_category, budgets_by_category)

    return render_template(
        "dashboard.html",
        total_income=total_income,
        total_expenses=total_expenses,
        net=total_income - total_expenses,
        expenses_by_category=expenses_by_category,
        total_saved=total_saved,
        insights=insights,
    )


@dashboard_bp.route("/reports")
@login_required
def reports():
    total_income, expenses_by_category, _ = _financial_snapshot()
    total_expenses = sum(expenses_by_category.values())

    return render_template(
        "reports.html",
        total_income=total_income,
        total_expenses=total_expenses,
        expenses_by_category=expenses_by_category,
    )


@dashboard_bp.route("/chat", methods=["GET", "POST"])
@login_required
def chat():
    reply = None
    user_message = None

    if request.method == "POST":
        user_message = request.form.get("message", "").strip()
        if user_message:
            total_income, expenses_by_category, _ = _financial_snapshot()
            context = {"total_income": total_income, "expenses_by_category": expenses_by_category}
            reply = chat_with_advisor(user_message, context)

    return render_template("chat.html", reply=reply, user_message=user_message)
